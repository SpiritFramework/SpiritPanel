-- AlterTable
ALTER TABLE `users` ADD COLUMN `avatar_url` VARCHAR(512) NULL;
